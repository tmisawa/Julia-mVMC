using MVMCOptimizers, LinearAlgebra, Profile, Statistics, SHA
BLAS.set_num_threads(1)
const M = MVMCOptimizers
input, output, steps_s, reps_s, profile_s = ARGS
steps, reps = parse(Int,steps_s), parse(Int,reps_s)
mkpath(output)
println("VERSION=",VERSION," BLAS=",BLAS.get_config()," THREADS=",Threads.nthreads()," INTERACTIVE=",Threads.nthreads(:interactive)," MAIN=",Threads.threadid())
function run(label)
    dest=joinpath(output,label)
    result=M.run_para_opt_from_namelist(joinpath(input,"namelist.def"); nsteps=steps, nsmp=1, mode=:real, seed=79, output_dir=dest)
    @assert result.status==0
    return result
end
run("warmup")
for rep in 1:reps
    GC.gc()
    stats=@timed run("rep$rep")
    println("BENCH rep=$rep seconds=$(stats.time) bytes=$(stats.bytes) gc=$(stats.gctime)")
    flush(stdout)
end
if profile_s=="profile"
    Profile.init(n=10^7,delay=.001)
    Profile.clear()
    stats=@timed Profile.@profile run("profile")
    println("PROFILE seconds=$(stats.time) bytes=$(stats.bytes) gc=$(stats.gctime)")
    for thread in (nothing,1)
        open(joinpath(output,"flat-$(thread).txt"),"w") do io
            if thread===nothing
                Profile.print(IOContext(io,:displaysize=>(20000,240));format=:flat,sortedby=:count,C=true,mincount=10)
            else
                Profile.print(IOContext(io,:displaysize=>(20000,240));format=:flat,sortedby=:count,C=true,mincount=10,threads=thread)
            end
        end
    end
end
